from flask import Flask, render_template, request, session # Import Flask to allow us to create our app
app = Flask(__name__)    # Create a new instance of the Flask class called "app"


@app.route('/')          # The "@" decorator associates this route with the function immediately following
def index():
    return render_template('index.html')


@app.route('/process', methods=['Post'])          # The "@" decorator associates this route with the function immediately following
def submitted():
    session['name'] = request.form['name']
    session['location'] = request.form['dojo_location']
    session['language'] = request.form['favorite_language']
    session['comment'] = request.form['comment']
    return render_template('index.html')


@app.route('/')          # The "@" decorator associates this route with the function immediately following
def displayInfo():
    return render_template('displayinfo.html')  


if __name__=="__main__":    
    app.run(debug=True)    
